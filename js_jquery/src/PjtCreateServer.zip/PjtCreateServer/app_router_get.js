var express = require("express");
var http = require("http");
var path = require("path");

var app = express();

app.use(express.static(path.join(__dirname, 'public')));

app.get("/login", function(req, res){
	console.log("user login");
	
	var uId = req.param("uId");
	var uPw = req.param("uPw");
	
	res.writeHead("200", {"Content-Type":"text/html;charset=utf8"});
	res.write("User ID :" + uId);
	res.write("<br>");
	res.write("User PW :" + uPw);
	res.write("<br>");
	res.write("<a href='/login_get.html'> LogIn </a>");
	res.end();
});

http.createServer(app).listen(3000, function(){
	console.log("server start!!");
});
var express = require("express");
var http = require("http");
var path = require("path");

var app = express();

app.use(function(req, res, next){
	console.log("use middleware");
	
	var paramInfo = req.param("info");
	
	res.writeHead("200", {"Content-Type":"text/html;charset=utf8"});
	res.write("paramInfo : " + paramInfo);
	res.end();
});

http.createServer(app).listen(3000, function(){
	console.log("server start!!");
});
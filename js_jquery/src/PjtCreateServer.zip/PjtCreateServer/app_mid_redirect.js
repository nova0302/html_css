var express = require("express");
var http = require("http");
var path = require("path");

var app = express();

app.use(function(req, res, next){
	console.log("use middleware redirect");
	
	res.redirect("http://www.seoulhackathon.com");
});

http.createServer(app).listen(3000, function(){
	console.log("server start!!");
});
/**
 * http://usejsdoc.org/
 */

var temVar = 2;

for(var i = 1; i < 10; i++) {
	console.log(temVar + " * " + i + " = " + (temVar*i));
}
